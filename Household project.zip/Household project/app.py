import streamlit as st
import pandas as pd
import joblib

# Load trained model
model = joblib.load("house_price_model.pkl")

# Page configuration
st.set_page_config(
    page_title="House Price Prediction",
    page_icon="🏠",
    layout="wide"
)

# Title
st.title("🏠 House Price Prediction System")
st.write("Predict house prices using Machine Learning")

st.divider()

st.subheader("Enter House Details")

# Input fields
col1, col2 = st.columns(2)

with col1:
    crim = st.number_input("CRIM", min_value=0.0, value=0.1)
    zn = st.number_input("ZN", min_value=0.0, value=0.0)
    indus = st.number_input("INDUS", min_value=0.0, value=5.0)
    chas = st.selectbox("CHAS", [0, 1])
    nox = st.number_input("NOX", min_value=0.0, value=0.5)
    rm = st.number_input("RM", min_value=1.0, value=6.0)
    age = st.number_input("AGE", min_value=0.0, max_value=100.0, value=50.0)

with col2:
    dis = st.number_input("DIS", min_value=0.0, value=4.0)
    rad = st.number_input("RAD", min_value=1, value=5)
    tax = st.number_input("TAX", min_value=0, value=300)
    ptratio = st.number_input("PTRATIO", min_value=0.0, value=18.0)
    b = st.number_input("B", min_value=0.0, value=350.0)
    lstat = st.number_input("LSTAT", min_value=0.0, value=12.0)

st.divider()

# Prediction button
if st.button("Predict House Price", type="primary"):

    input_data = pd.DataFrame([[
        crim, zn, indus, chas, nox, rm, age,
        dis, rad, tax, ptratio, b, lstat
    ]], columns=[
        'CRIM', 'ZN', 'INDUS', 'CHAS', 'NOX',
        'RM', 'AGE', 'DIS', 'RAD', 'TAX',
        'PTRATIO', 'B', 'LSTAT'
    ])

    prediction = model.predict(input_data)

    price = float (prediction[0])*100000

    st.success("Prediction Completed!")

    st.subheader("Predicted House Price")

    st.metric("Estimated House Price", f"₹{price:.2f}")

    st.info(
        "This prediction is based on the trained "
        "Machine Learning model and the supplied data."
    )

st.divider()

st.caption("House Price Prediction | Machine Learning Project")