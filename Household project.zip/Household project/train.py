import pandas as pd
import joblib

from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler, PolynomialFeatures
from sklearn.linear_model import Ridge

df = pd.read_csv("HousingData.csv")

X = df.drop("MEDV", axis=1)
y = df["MEDV"]

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

pipe = Pipeline([
    ("imputer", SimpleImputer(strategy="median")),
    ("scaler", StandardScaler()),
    ("poly", PolynomialFeatures(degree=2, include_bias=False)),
    ("model", Ridge())
])

params = {
    "model__alpha": [0.001, 0.01, 0.1, 1, 10, 100, 500]
}

grid = GridSearchCV(pipe, params, cv=5, scoring="r2")
grid.fit(X_train, y_train)

joblib.dump(grid.best_estimator_, "house_price_model.pkl")

print("Model trained and saved successfully!")
print("Best Parameters:", grid.best_params_)