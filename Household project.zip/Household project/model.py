from sklearn.model_selection import train_test_split, RandomizedSearchCV
from sklearn.ensemble import RandomForestRegressor, ExtraTreesRegressor, VotingRegressor
from sklearn.metrics import mean_squared_error, r2_score, mean_absolute_error
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer

# Split dataset
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

# Random Forest
rf = RandomForestRegressor(random_state=42)

# Extra Trees
et = ExtraTreesRegressor(random_state=42)

# Parameter tuning
param_grid = {
    "n_estimators": [200, 300, 500, 700],
    "max_depth": [None, 10, 20, 30],
    "min_samples_split": [2, 5, 10],
    "min_samples_leaf": [1, 2, 4],
    "max_features": [1.0, "sqrt", 0.8]
}

search = RandomizedSearchCV(
    rf,
    param_distributions=param_grid,
    n_iter=30,
    cv=5,
    scoring="r2",
    n_jobs=-1,
    random_state=42
)

# Train model
search.fit(X_train, y_train)

# Best model
best_rf = search.best_estimator_

# Predictions
y_pred = best_rf.predict(X_test)

# Performance
mse = mean_squared_error(y_test, y_pred)
mae = mean_absolute_error(y_test, y_pred)
r2 = r2_score(y_test, y_pred)

print("\nOptimized Model Performance:")
print("Best Parameters:", search.best_params_)
print("Mean Squared Error:", mse)
print("Mean Absolute Error:", mae)
print("R2 Score:", r2)
print(f"Accuracy-like Metric (+- {tolerance}): {(abs(y_test - y_pred) <= tolerance).mean() * 100:.2f}%")